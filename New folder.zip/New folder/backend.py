from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Database model
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_name = db.Column(db.String(100), nullable=False)
    student_class = db.Column(db.String(20))
    student_dob = db.Column(db.String(20))
    student_city = db.Column(db.String(50))
    student_state = db.Column(db.String(50))
    student_stream = db.Column(db.String(50))
    student_subjects = db.Column(db.String(100))
    student_admno = db.Column(db.String(50), unique=True)
    student_doadm = db.Column(db.String(20))

    def __repr__(self):
        return f"<Student {self.student_name}>"

with app.app_context():
    db.create_all()

@app.route('/', methods=["GET", "POST"])
def home():
    if request.method == "POST":
        new_student = Student(
            student_name=request.form.get("student_name"),
            student_class=request.form.get("student_class"),
            student_dob=request.form.get("student_dob"),
            student_city=request.form.get("student_city"),
            student_state=request.form.get("student_state"),
            student_stream=request.form.get("student_stream"),
            student_subjects=request.form.get("student_subjects"),
            student_admno=request.form.get("student_admno"),
            student_doadm=request.form.get("student_doadm")
        )
        db.session.add(new_student)
        db.session.commit()
        return redirect(url_for('home'))

    students = Student.query.all()
    return render_template('list.html', form_data=students)

@app.route('/edit/<int:student_id>', methods=["GET", "POST"])
def edit(student_id):
    student = Student.query.get_or_404(student_id)

    if request.method == "POST":
        student.student_name = request.form.get("student_name")
        student.student_class = request.form.get("student_class")
        student.student_dob = request.form.get("student_dob")
        student.student_city = request.form.get("student_city")
        student.student_state = request.form.get("student_state")
        student.student_stream = request.form.get("student_stream")
        student.student_subjects = request.form.get("student_subjects")
        student.student_admno = request.form.get("student_admno")
        student.student_doadm = request.form.get("student_doadm")

        db.session.commit()
        return redirect(url_for('home'))

    return render_template('update.html', student=student)

@app.route('/delete/<int:student_id>', methods=["POST"])
def delete(student_id):
    student = Student.query.get_or_404(student_id)
    db.session.delete(student)
    db.session.commit()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True, port=4000)
